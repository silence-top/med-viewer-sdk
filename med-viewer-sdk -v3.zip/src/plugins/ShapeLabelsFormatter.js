/**
 * @param {any} annotation
 * @returns {SVGForeignObjectElement}
 */

// const pathDataParser = require("path-data-parser");
// import { svgPathProperties } from "svg-path-properties";
import { svgPathProperties } from "svg-path-properties";
import { t } from "../i18n/i18n";
function getWithUnit(value, unitSuffix) {
  // if (value < 0.000001) {
  //   return (value * 1000000000).toFixed(2) + "n" + unitSuffix;
  // }
  // if (value < 0.001) {
  return value.toFixed(2) + "μ" + unitSuffix;
  // }
  // if (value < 1) {
  // return (value * 1000).toFixed(2) + "m" + unitSuffix;
  // }
  // if (value >= 1000) {
  //   return (value / 1000).toFixed(2) + "k" + unitSuffix;
  // }
  // return value + " " + unitSuffix;
}

function pixelsToPerMeter(value, pixelsPerMeter) {
  let nweValue = value / pixelsPerMeter;
  return nweValue * 1000000;
}

const ShapeLabelsFormatter = (pixelsPerMeter, showMeasure) => (annotation) => {
  const bodies = Array.isArray(annotation.body)
    ? annotation.body
    : [annotation.body];
  let toolName = annotation.target.renderedVia?.name;
  if (!showMeasure) {
    toolName = null;
  }

  const foreignObject = document.createElementNS(
    "http://www.w3.org/2000/svg",
    "foreignObject",
  );
  foreignObject.setAttribute("width", "1px");
  foreignObject.setAttribute("height", "1px");
  const firstTag = bodies.find((b) => b.purpose == "commenting");

  switch (toolName) {
    case "line":
      console.log("line", annotation.target.selector.value);
      let lineDiv = document.createElement("div");
      lineDiv.innerHTML = annotation.target.selector.value;
      let line = lineDiv.getElementsByTagName("line")[0];
      let x1 = pixelsToPerMeter(
        Number(line.getAttribute("x1")),
        pixelsPerMeter,
      );
      let y1 = pixelsToPerMeter(
        Number(line.getAttribute("y1")),
        pixelsPerMeter,
      );
      let x2 = pixelsToPerMeter(
        Number(line.getAttribute("x2")),
        pixelsPerMeter,
      );
      let y2 = pixelsToPerMeter(
        Number(line.getAttribute("y2")),
        pixelsPerMeter,
      );
      let len = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
      // realLen = getWithUnit((len / config.scalebarInstance.pixelsPerMeter), 'm');
      if (firstTag) {
        foreignObject.innerHTML = `
    <div xmlns="http://www.w3.org/1999/xhtml" class="a9s-shape-label-wrapper">
<div  class="a9s-shape-label" >
      <p >
       ${t(`annotation.length`)}:&nbsp;&nbsp;${getWithUnit(
         len,
         "m",
       )}&nbsp;&nbsp; </p> <p >
       ${t(`annotation.remark`)}:&nbsp;&nbsp;${firstTag.value}&nbsp;&nbsp;
      </p>
      </div>
    </div>`;
      } else {
        foreignObject.innerHTML = `
    <div xmlns="http://www.w3.org/1999/xhtml" class="a9s-shape-label-wrapper">

    <div class="a9s-shape-label" >
      <p>
       ${t(`annotation.length`)}:&nbsp;&nbsp;${getWithUnit(len, "m")}&nbsp;&nbsp;
      </p>
      </div>
    </div>`;
      }

      break;
    case "rect":
      let reg = new RegExp("xywh=pixel:", "g");
      let str = annotation.target.selector.value.replace(reg, "");
      let point = str.split(",");

      const rectWidth = pixelsToPerMeter(Number(point[2]), pixelsPerMeter); // 请根据你的实际情况替换为正确的半径值
      const rectHeight = pixelsToPerMeter(Number(point[3]), pixelsPerMeter); // 替换为正确的高度值

      // 计算${t(`perimeter`)}
      const rectPerimeter = 2 * (rectWidth + rectHeight);

      // 计算${t(`area`)}
      const rectArea = rectWidth * rectHeight;

      if (firstTag) {
        foreignObject.innerHTML = `
    <div xmlns="http://www.w3.org/1999/xhtml" class="a9s-shape-label-wrapper">

    <div class="a9s-shape-label">
      <p>
      ${t(`annotation.width`)}:&nbsp;&nbsp;${getWithUnit(
        rectWidth,
        "m",
      )}&nbsp;&nbsp;</p> <p>


      ${t(`annotation.height`)}:&nbsp;&nbsp;${getWithUnit(
        rectHeight,
        "m",
      )}&nbsp;&nbsp;</p> <p>
       ${t(`annotation.perimeter`)}:&nbsp;&nbsp;${getWithUnit(
         rectPerimeter,
         "m",
       )}&nbsp;&nbsp;</p> <p>
       ${t(`annotation.area`)}:&nbsp;&nbsp;${getWithUnit(
         rectArea,
         "m²",
       )}&nbsp;&nbsp;</p> <p>
       ${t(`annotation.remark`)}:&nbsp;&nbsp;${firstTag.value}&nbsp;&nbsp;
      </p>
      </div>
    </div>`;
      } else {
        foreignObject.innerHTML = `
    <div xmlns="http://www.w3.org/1999/xhtml" class="a9s-shape-label-wrapper">
    <div class="a9s-shape-label">
      <p >
      ${t(`annotation.width`)}:&nbsp;&nbsp;${getWithUnit(
        rectWidth,
        "m",
      )}&nbsp;&nbsp;</p>  <p>
      ${t(`annotation.height`)}:&nbsp;&nbsp;${getWithUnit(
        rectHeight,
        "m",
      )}&nbsp;&nbsp;</p>  <p>
        ${t(`annotation.perimeter`)}:&nbsp;&nbsp;${getWithUnit(
          rectPerimeter,
          "m",
        )}&nbsp;&nbsp;</p>  <p>
       ${t(`annotation.area`)}:&nbsp;&nbsp;${getWithUnit(rectArea, "m²")}&nbsp;&nbsp;
      </p>
      </div>
    </div>`;
      }
      break;
    case "circle":
      let circleDiv = document.createElement("div");

      console.log(annotation);
      circleDiv.innerHTML = annotation.target.selector.value;
      let circle = circleDiv.getElementsByTagName("circle")[0];
      const circleRadius = pixelsToPerMeter(
        Number(circle.getAttribute("r")),
        pixelsPerMeter,
      ); // 请根据你的实际情况替换为正确的半径值

      // 计算${t(`perimeter`)}
      const circleCircumference = 2 * Math.PI * circleRadius;
      // 计算${t(`area`)}
      const circleArea = Math.PI * Math.pow(circleRadius, 2);

      if (firstTag) {
        foreignObject.innerHTML = `
    <div xmlns="http://www.w3.org/1999/xhtml" class="a9s-shape-label-wrapper">

    <div class="a9s-shape-label">
      <p>
      ${t(`annotation.radius`)}:&nbsp;&nbsp;${getWithUnit(
        circleRadius,
        "m",
      )}&nbsp;&nbsp;</p><p>
       ${t(`annotation.perimeter`)}:&nbsp;&nbsp;${getWithUnit(
         circleCircumference,
         "m",
       )}&nbsp;&nbsp;</p><p>
       ${t(`annotation.area`)}:&nbsp;&nbsp;${getWithUnit(
         circleArea,
         "m²",
       )}&nbsp;&nbsp;</p><p>
       ${t(`annotation.remark`)}:&nbsp;&nbsp;${firstTag.value}&nbsp;&nbsp;
      </p>
      </div>
    </div>`;
      } else {
        foreignObject.innerHTML = `
    <div xmlns="http://www.w3.org/1999/xhtml" class="a9s-shape-label-wrapper">
    <div class="a9s-shape-label"> 
      <p>
      ${t(`annotation.radius`)}:&nbsp;&nbsp;${getWithUnit(
        circleRadius,
        "m",
      )}&nbsp;&nbsp;</p><p>
        ${t(`annotation.perimeter`)}:&nbsp;&nbsp;${getWithUnit(
          circleCircumference,
          "m",
        )}&nbsp;&nbsp;</p><p>
       ${t(`annotation.area`)}:&nbsp;&nbsp;${getWithUnit(
         circleArea,
         "m²",
       )}&nbsp;&nbsp;
     
      </p>
      </div>
    </div>`;
      }

      break;
    case "ellipse":
      let ellipseDiv = document.createElement("div");
      ellipseDiv.innerHTML = annotation.target.selector.value;
      let ellipse = ellipseDiv.getElementsByTagName("ellipse")[0];

      let rx = pixelsToPerMeter(
        Number(ellipse.getAttribute("rx")),
        pixelsPerMeter,
      );
      let ry = pixelsToPerMeter(
        Number(ellipse.getAttribute("ry")),
        pixelsPerMeter,
      );
      let majorAxis = null;
      let minorAxis = null;
      if (rx >= ry) {
        majorAxis = rx;
        minorAxis = ry;
      } else {
        majorAxis = ry;
        minorAxis = rx;
      }
      const ellipsePerimeter =
        Math.PI * (3 * (rx + ry) - Math.sqrt((3 * rx + ry) * (rx + 3 * ry)));

      // 计算${t(`area`)}
      const ellipseArea = Math.PI * rx * ry;
      if (firstTag) {
        foreignObject.innerHTML = `
    <div xmlns="http://www.w3.org/1999/xhtml" class="a9s-shape-label-wrapper">
    <div class="a9s-shape-label">
      <p>
      ${t(`annotation.majorAxis`)}:&nbsp;&nbsp;${getWithUnit(
        majorAxis,
        "m",
      )}&nbsp;&nbsp;</p> <p>

       ${t(`annotation.minorAxis`)}:&nbsp;&nbsp;${getWithUnit(
         minorAxis,
         "m",
       )}&nbsp;&nbsp;</p> <p>
       ${t(`annotation.perimeter`)}:&nbsp;&nbsp;${getWithUnit(
         ellipsePerimeter,
         "m",
       )}&nbsp;&nbsp;</p> <p>
       ${t(`annotation.area`)}:&nbsp;&nbsp;${getWithUnit(
         ellipseArea,
         "m²",
       )}&nbsp;&nbsp;</p> <p>
       ${t(`annotation.remark`)}:&nbsp;&nbsp;${firstTag.value}&nbsp;&nbsp;
      </p>
      </div>
    </div>`;
      } else {
        foreignObject.innerHTML = `
    <div xmlns="http://www.w3.org/1999/xhtml" class="a9s-shape-label-wrapper">
    <div class="a9s-shape-label">
      <p>
      ${t(`annotation.majorAxis`)}:&nbsp;&nbsp;${getWithUnit(
        majorAxis,
        "m",
      )}&nbsp;&nbsp;</p><p>
    
       ${t(`annotation.minorAxis`)}:&nbsp;&nbsp;${getWithUnit(
         minorAxis,
         "m",
       )}&nbsp;&nbsp;</p><p>
        ${t(`annotation.perimeter`)}:&nbsp;&nbsp;${getWithUnit(
          ellipsePerimeter,
          "m",
        )}&nbsp;&nbsp;</p><p>
       ${t(`annotation.area`)}:&nbsp;&nbsp;${getWithUnit(
         ellipseArea,
         "m²",
       )}&nbsp;&nbsp;
      </p>
      </div>
    </div>`;
      }

      break;
    case "polygon":
      let polygonDiv = document.createElement("div");
      polygonDiv.innerHTML = annotation.target.selector.value;

      let polygon = polygonDiv.getElementsByTagName("polygon")[0];
      let pointsAttribute = polygon.getAttribute("points");
      const points = pointsAttribute.split(" ").map((point) => {
        const [x, y] = point.split(",").map(parseFloat);
        return {
          x: pixelsToPerMeter(x, pixelsPerMeter),
          y: pixelsToPerMeter(y, pixelsPerMeter),
        };
      });

      // 计算${t(`perimeter`)}
      let polygonPerimeter = 0;
      for (let i = 0; i < points.length; i++) {
        const currentPoint = points[i];
        const nextPoint = points[(i + 1) % points.length];
        const dx = nextPoint.x - currentPoint.x;
        const dy = nextPoint.y - currentPoint.y;
        polygonPerimeter += Math.sqrt(dx * dx + dy * dy);
      }

      // 计算${t(`area`)}
      let polygonArea = 0;
      for (let i = 0; i < points.length; i++) {
        const currentPoint = points[i];
        const nextPoint = points[(i + 1) % points.length];
        polygonArea +=
          currentPoint.x * nextPoint.y - nextPoint.x * currentPoint.y;
      }
      polygonArea = Math.abs(polygonArea) / 2;
      if (firstTag) {
        foreignObject.innerHTML = `
    <div xmlns="http://www.w3.org/1999/xhtml" class="a9s-shape-label-wrapper">
    <div class="a9s-shape-label">
      <p>
       ${t(`annotation.perimeter`)}:&nbsp;&nbsp;${getWithUnit(
         polygonPerimeter,
         "m",
       )}&nbsp;&nbsp;</p> <p>
       ${t(`annotation.area`)}:&nbsp;&nbsp;${getWithUnit(
         polygonArea,
         "m²",
       )}&nbsp;&nbsp;</p> <p>
       ${t(`annotation.remark`)}:&nbsp;&nbsp;${firstTag.value}&nbsp;&nbsp;
      </p>
      </div>
    </div>`;
      } else {
        foreignObject.innerHTML = `
    <div xmlns="http://www.w3.org/1999/xhtml" class="a9s-shape-label-wrapper">

    <div class="a9s-shape-label">
      <p>
        ${t(`annotation.perimeter`)}:&nbsp;&nbsp;${getWithUnit(
          polygonPerimeter,
          "m",
        )}&nbsp;&nbsp;</p><p>
       ${t(`annotation.area`)}:&nbsp;&nbsp;${getWithUnit(
         polygonArea,
         "m²",
       )}&nbsp;&nbsp;
      </p>
      </div>
    </div>`;
      }

      break;
    case "freehand":
      // 解析 path
      let pathDiv = document.createElement("div");
      pathDiv.innerHTML = annotation.target.selector.value;

      let path = pathDiv.getElementsByTagName("path")[0];
      let d = path.getAttribute("d");

      // 使用 svg-path-properties 解析曲线
      const properties = new svgPathProperties(d);

      // 周长（像素）
      let pixelPerimeter = properties.getTotalLength();

      // 离散化路径为点（越多越精确）
      let steps = 300; // 建议 200~500
      let freehandPoints = [];
      for (let i = 0; i <= steps; i++) {
        let pos = properties.getPointAtLength((i / steps) * pixelPerimeter);
        freehandPoints.push([pos.x, pos.y]);
      }

      // 计算面积（鞋带公式）
      let areaPixel = computeFreehandArea(freehandPoints);

      // 转换单位（你的 config）
      let realPerimeter = pixelsToPerMeter(pixelPerimeter, pixelsPerMeter);

      // 面积单位转换（像素² → μm²）
      // pixelsToPerMeter(1) = 1 像素对应多少 μm
      let pixelToMicro = pixelsToPerMeter(1, pixelsPerMeter);
      let realArea = areaPixel * pixelToMicro * pixelToMicro;

      // 鞋带公式
      function computeFreehandArea(freehandPoints) {
        let sum = 0;
        for (let i = 0; i < freehandPoints.length - 1; i++) {
          const [x1, y1] = freehandPoints[i];
          const [x2, y2] = freehandPoints[i + 1];
          sum += x1 * y2 - x2 * y1;
        }
        return Math.abs(sum / 2);
      }

      if (firstTag) {
        foreignObject.innerHTML = `
          <div xmlns="http://www.w3.org/1999/xhtml" class="a9s-shape-label-wrapper">
            <div class="a9s-shape-label">
              <p>${t(`annotation.length`)}:&nbsp;&nbsp;${getWithUnit(realPerimeter, "m")}</p>
              <p>${t(`annotation.area`)}:&nbsp;&nbsp;${getWithUnit(realArea, "m²")}</p>
              <p>${t(`annotation.remark`)}:&nbsp;&nbsp;${firstTag.value}</p>
            </div>
          </div>`;
      } else {
        foreignObject.innerHTML = `
          <div xmlns="http://www.w3.org/1999/xhtml" class="a9s-shape-label-wrapper">
            <div class="a9s-shape-label">
              <p>${t(`annotation.length`)}:&nbsp;&nbsp;${getWithUnit(realPerimeter, "m")}</p>
              <p>${t(`annotation.area`)}:&nbsp;&nbsp;${getWithUnit(realArea, "m²")}</p>
            </div>
          </div>`;
      }

      break;

    default:
      if (firstTag) {
        foreignObject.innerHTML = `
            <div xmlns="http://www.w3.org/1999/xhtml" class="a9s-shape-label-wrapper">
            <div class="a9s-shape-label">
              <p>
               ${t(`annotation.remark`)}:&nbsp;&nbsp;${firstTag.value}&nbsp;&nbsp;
              </p>
              </div>
            </div>`;
      }
    // 如果没有与表达式相同的值，则执行该代码
  }

  return {
    element: foreignObject,
  };
};
const injectShapeLabelStyles = () => {
  // 适配医学影像的样式（v2.7.17 默认样式有时在深色背景下不明显）
  const styleId = "med-anno-default-shapeLabelsFormatter-overrides";
  if (document.getElementById(styleId)) return;
  const style = document.createElement("style");
  style.id = styleId;
  style.innerHTML = `
          
.a9s-annotationlayer .a9s-formatter-el,
.a9s-annotationlayer .a9s-formatter-el foreignObject {
  overflow: visible;
  pointer-events: none;
}

.a9s-annotationlayer .a9s-formatter-el foreignObject .a9s-shape-label-wrapper {
  position: relative;
  transform: translateY(-100%);
  padding-bottom: 4px;
}

.a9s-annotationlayer
  .a9s-formatter-el
  foreignObject
  .a9s-shape-label-wrapper
  .a9s-shape-label {
  display: inline-block;
  max-width: 24vw !important;
  color: #000;
  /* min-width: 10vw !important; */

  word-wrap: break-word;
  word-break: keep-all;
  /* white-space: nowrap;  */

  padding: 3px 5px;
  margin-bottom: 2px;
  background-color: rgba(255, 255, 255, 0.85);
  border-radius: 3px;
  font-size: 14px;
}

.a9s-annotationlayer
  .a9s-formatter-el
  foreignObject
  .a9s-shape-label-wrapper
  .a9s-shape-label
  p {
  margin: 5px !important;
}
    `;
  document.head.appendChild(style);
};

export { ShapeLabelsFormatter, injectShapeLabelStyles };
