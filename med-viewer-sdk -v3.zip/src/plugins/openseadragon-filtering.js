import OpenSeadragon from "openseadragon";

(function($) {
    'use strict';

    // 1. 安全检查：确保 OpenSeadragon 存在
    if (!$) {
        console.error('Filter plugin requires OpenSeadragon to be loaded first.');
        return;
    }

    // 2. 版本检查：要求 2.1.0+
    if (!$.version || $.version.major < 2 || ($.version.major === 2 && $.version.minor < 1)) {
        throw new Error('Filtering plugin requires OpenSeadragon version >= 2.1');
    }

    // --- 挂载 prototype 方法 ---
    $.Viewer.prototype.setFilterOptions = function(options) {
        if (!this.filterPluginInstance) {
            options = options || {};
            options.viewer = this;
            this.filterPluginInstance = new $.FilterPlugin(options);
        } else {
            setOptions(this.filterPluginInstance, options);
        }
    };

    // --- 核心插件类 ---
    $.FilterPlugin = function(options) {
        options = options || {};
        if (!options.viewer) {
            throw new Error('A viewer must be specified.');
        }
        var self = this;
        this.viewer = options.viewer;

        // 注册事件监听
        this.viewer.addHandler('tile-loaded', tileLoadedHandler);
        this.viewer.addHandler('tile-drawing', tileDrawingHandler);

        this.filterIncrement = 0;
        setOptions(this, options);

        function tileLoadedHandler(event) {
            var processors = getFiltersProcessors(self, event.tiledImage);
            if (processors.length === 0) return;
            
            var image = event.image;
            if (image) {
                var canvas = window.document.createElement('canvas');
                canvas.width = image.width;
                canvas.height = image.height;
                var context = canvas.getContext('2d');
                context.drawImage(image, 0, 0);
                event.tile._renderedContext = context;
                var callback = event.getCompletionCallback();
                applyFilters(context, processors, callback);
                event.tile._filterIncrement = self.filterIncrement;
            }
        }

        function applyFilters(context, filtersProcessors, callback) {
            if (callback) {
                var currentIncrement = self.filterIncrement;
                var callbacks = [];
                for (var i = 0; i < filtersProcessors.length - 1; i++) {
                    (function(idx) {
                        callbacks[idx] = function() {
                            if (self.filterIncrement !== currentIncrement) return;
                            filtersProcessors[idx + 1](context, callbacks[idx + 1]);
                        };
                    })(i);
                }
                callbacks[filtersProcessors.length - 1] = function() {
                    if (self.filterIncrement !== currentIncrement) return;
                    callback();
                };
                filtersProcessors[0](context, callbacks[0]);
            } else {
                for (var j = 0; j < filtersProcessors.length; j++) {
                    filtersProcessors[j](context, function() {});
                }
            }
        }

        function tileDrawingHandler(event) {
            var rendered = event.rendered;
            if (rendered._filterIncrement === self.filterIncrement) return;

            var processors = getFiltersProcessors(self, event.tiledImage);
            if (processors.length === 0) {
                if (rendered._originalImageData) {
                    rendered.putImageData(rendered._originalImageData, 0, 0);
                    delete rendered._originalImageData;
                }
                rendered._filterIncrement = self.filterIncrement;
                return;
            }

            if (!rendered._originalImageData) {
                rendered._originalImageData = rendered.getImageData(0, 0, rendered.canvas.width, rendered.canvas.height);
            } else {
                rendered.putImageData(rendered._originalImageData, 0, 0);
            }

            var tile = event.tile;
            if (tile._renderedContext) {
                if (tile._filterIncrement === self.filterIncrement) {
                    var imgData = tile._renderedContext.getImageData(0, 0, tile._renderedContext.canvas.width, tile._renderedContext.canvas.height);
                    rendered.putImageData(imgData, 0, 0);
                    delete tile._renderedContext;
                    delete tile._filterIncrement;
                    rendered._filterIncrement = self.filterIncrement;
                    return;
                }
                delete tile._renderedContext;
            }
            applyFilters(rendered, processors);
            rendered._filterIncrement = self.filterIncrement;
        }
    };

    // --- 内部辅助函数 ---
    function setOptions(instance, options) {
        options = options || {};
        var filters = options.filters;
        instance.filters = !filters ? [] : (Array.isArray(filters) ? filters : [filters]);
        
        instance.filters.forEach(function(f) {
            if (!f.processors) throw new Error('Filter processors must be specified.');
            f.processors = Array.isArray(f.processors) ? f.processors : [f.processors];
        });

        instance.filterIncrement++;
        if (options.loadMode === 'sync') {
            instance.viewer.forceRedraw();
        } else {
            var itemsToReset = [];
            instance.filters.forEach(function(f) {
                if (!f.items) {
                    itemsToReset = getAllItems(instance.viewer.world);
                } else {
                    var items = Array.isArray(f.items) ? f.items : [f.items];
                    items.forEach(function(item) {
                        if (itemsToReset.indexOf(item) === -1) itemsToReset.push(item);
                    });
                }
            });
            itemsToReset.forEach(function(item) { item.reset(); });
        }
    }

    function getAllItems(world) {
        var res = [];
        for (var i = 0; i < world.getItemCount(); i++) res.push(world.getItemAt(i));
        return res;
    }

    function getFiltersProcessors(instance, item) {
        if (instance.filters.length === 0) return [];
        var globalProcessors = null;
        for (var i = 0; i < instance.filters.length; i++) {
            var f = instance.filters[i];
            if (!f.items) globalProcessors = f.processors;
            else if (f.items === item || (Array.isArray(f.items) && f.items.indexOf(item) >= 0)) return f.processors;
        }
        return globalProcessors || [];
    }

    // --- 预置滤镜库 ---
    $.Filters = {
        GREYSCALE: function() {
            return function(context, callback) {
                var imgData = context.getImageData(0, 0, context.canvas.width, context.canvas.height);
                var p = imgData.data;
                for (var i = 0; i < p.length; i += 4) {
                    var val = (p[i] + p[i+1] + p[i+2]) / 3;
                    p[i] = p[i+1] = p[i+2] = val;
                }
                context.putImageData(imgData, 0, 0);
                callback();
            };
        },
        INVERT: function() {
            return function(context, callback) {
                var imgData = context.getImageData(0, 0, context.canvas.width, context.canvas.height);
                var p = imgData.data;
                for (var i = 0; i < p.length; i += 4) {
                    p[i] = 255 - p[i];
                    p[i+1] = 255 - p[i+1];
                    p[i+2] = 255 - p[i+2];
                }
                context.putImageData(imgData, 0, 0);
                callback();
            };
        },
        BRIGHTNESS: function(adj) {
            return function(context, callback) {
                var imgData = context.getImageData(0, 0, context.canvas.width, context.canvas.height);
                var p = imgData.data;
                for (var i = 0; i < p.length; i += 4) {
                    p[i] += adj; p[i+1] += adj; p[i+2] += adj;
                }
                context.putImageData(imgData, 0, 0);
                callback();
            };
        }
        // ... 其他滤镜可以按此格式继续添加
    };

})(OpenSeadragon);